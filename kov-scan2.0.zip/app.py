"""
KOV-SCAN 2.0 - Active Reconnaissance Tool
Created by: brutozin.kov
License: Educational Purpose Only
"""
import sys
import argparse
import webbrowser
import threading
def start_gui():
    try:
        from web.app import app
        print("\n[*] Starting Web Scan .")
        print("[*] Opening browser at http://localhost:5000")
        threading.Timer(1.5, lambda: webbrowser.open('http://localhost:5000')).start()
        app.run(host='0.0.0.0', port=5000, debug=False)
    except ImportError:
        print("[-] Install: pip install flask flask-socketio")
        sys.exit(1)
def start_cli():
    from ui.printer import show_title
    from scanners.passive_checks import all_in_one_passive
    from scanners.active_checks import ActiveRecon
    from utils.helpers import ensure_requirements, save_scan_prompt    
    ensure_requirements()
    show_title()    
    print("\nKOV-SCAN 2.0 - ACTIVE RECON MODE")
    print("[!] Only scan authorized targets!\n")    
    while True:
        target = input("Target (example.com): ").strip()
        if target.lower() in ('exit', 'quit', 'q'):
            print("\nExiting KOV-SCAN 2.0. Stay legal.")
            break
        if not target:
            continue       
        print("\n[1] Running PASSIVE reconnaissance...")
        passive_result = all_in_one_passive(target)       
        print("\n[2] Running ACTIVE reconnaissance...")
        active = ActiveRecon(target)
        active_result = active.run_all()       
        combined = {**passive_result, **active_result}       
        from ui.printer import print_active_report
        print_active_report(combined)        
        save = input("\nSave results? (y/n): ").strip().lower()
        if save == 'y':
            save_scan_prompt(combined)
def main():
    parser = argparse.ArgumentParser(description='KOV-SCAN 2.0 - Created by brutozin.kov')
    parser.add_argument('-g', '--gui', action='store_true', help='Start web GUI')
    parser.add_argument('-t', '--target', help='Target domain to scan')
    parser.add_argument('-a', '--active', action='store_true', help='Active recon only')
    parser.add_argument('-p', '--passive', action='store_true', help='Passive recon only')    
    args = parser.parse_args()   
    if args.gui:
        start_gui()
    elif args.target:
        from ui.printer import show_title
        from scanners.passive_checks import all_in_one_passive
        from scanners.active_checks import ActiveRecon
        from utils.helpers import save_scan_prompt
        show_title()
        print(f"\n[*] Scanning: {args.target}")
        if args.passive or not args.active:
            passive_result = all_in_one_passive(args.target)
        if args.active or not args.passive:
            active = ActiveRecon(args.target)
            active_result = active.run_all()
        
        if args.active and args.passive:
            combined = {**passive_result, **active_result}
            from ui.printer import print_active_report
            print_active_report(combined)
    else:
        start_cli()
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted. Exiting.")
        sys.exit(0)