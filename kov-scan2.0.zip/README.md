# 🔥 KOV-SCAN 2.0

**Active Reconnaissance & Vulnerability Scanner for Bug Bounty & Security Testing**

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Version](https://img.shields.io/badge/Version-2.0-green.svg)
![License](https://img.shields.io/badge/License-Educational-red.svg)

> ⚡ Fast • Modular • CLI + GUI • AI-ready

---

## 📌 Overview

**KOV-SCAN 2.0** is a powerful Python-based reconnaissance and vulnerability scanning tool designed for **bug bounty hunters and security researchers**.

It combines:
- Passive OSINT  
- Active reconnaissance  
- Web analysis  
- Basic vulnerability detection  

---

## 🚀 Features

### 🧠 Passive Intelligence (OSINT)
- DNS Enumeration (A, AAAA, MX, NS, TXT, SOA)
- WHOIS Lookup
- IP Intelligence
- SSL/TLS Certificate Analysis
- Technology Detection (CMS, frameworks)
- Email Extraction

---

### ⚡ Active Reconnaissance
- Port Scanning (Top 25 ports)
- Service & Banner Detection
- Subdomain Enumeration
- Directory Bruteforce (50+ paths)
- WAF Detection (Cloudflare, AWS, Sucuri)

---

### 🌐 Web Analysis
- HTTP Header Inspection
- Security Header Checks
- Response Analysis
- Performance Metrics

---

### 🚨 Vulnerability Detection
- Sensitive File Exposure (`.env`, `.git`, backups)
- Missing Security Headers
- Outdated Server Versions
- Open Risky Ports
- Cookie Security Issues
- Basic OWASP Top 10 checks

---

### 🖥️ Interface
- Interactive CLI Mode  
- One-shot CLI Commands  
- Web GUI Dashboard  

---

## 📦 Installation

### 1️⃣ Clone Repository
git clone https://github.com/brutozin/kov-scan-2.0.git
cd kov-scan-2.0

### 2️⃣ Install Dependencies
pip install -r requirements.txt

### 3️⃣ Verify Installation
python app.py -h

---

## ⚡ Quick Start

### ▶️ One-Liner Scan
python app.py -t example.com

### 🧑‍💻 Interactive Mode
python app.py

### 🌐 GUI Mode
python app.py -g

Open browser: http://localhost:5000

---

## 🛠️ Usage

| Argument | Description | Example |
|----------|------------|--------|
| -t, --target | Target domain | -t example.com |
| -a, --active | Active scan only | -t example.com -a |
| -p, --passive | Passive scan only | -t example.com -p |
| -g, --gui | Launch GUI | -g |
| -h, --help | Show help | -h |

---

## 🔍 Scan Workflow

Target → Passive Recon → Active Recon → Analysis → Report

---

## 📊 Example Output

[+] Target: example.com
[+] IP: 93.184.216.34
[+] Ports: 80, 443
[+] Subdomains: dev.example.com
[!] Possible Issue: Missing HSTS Header

---

## 📁 Report Generation

Reports are saved in .txt format.

Example:
KOV-SCAN 2.0 - Scan Report

Target: example.com
IP: 93.184.216.34

--- FINDINGS ---
[HIGH] Missing Security Headers
[MEDIUM] Open Port 3306
[LOW] Server Info Disclosure

---

## ⚙️ Requirements

### 🔧 Python Dependencies
- requests  
- beautifulsoup4  
- colorama  
- dnspython  
- flask  
- pyOpenSSL  

Install all:
pip install -r requirements.txt

---

## 💡 Recommended Environment
- Python 3.8+  
- Linux / Termux / WSL  
- 2GB RAM recommended  

---

## ⚠️ Legal Disclaimer

This tool is for educational and authorized testing only.

✔ Only scan systems you own or have permission to test  
❌ Unauthorized scanning is illegal  

The developer is not responsible for misuse.

---

## 👨‍💻 Author

brutozin.kov

---

## 🔮 Future Plans
- AI integration (auto analysis)
- Telegram bot control
- JSON output mode
- Plugin system

---

## ⭐ Support

If you like this project:
- Star the repo  
- Report bugs  
- Contribute  

---

## 📜 License

Educational Use Only
