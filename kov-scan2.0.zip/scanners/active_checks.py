"""
KOV-SCAN 2.0 Active Recon Module
Created by: brutozin.kov
"""

import socket
import requests
import dns.resolver
from concurrent.futures import ThreadPoolExecutor, as_completed
from core.port_scanner import PortScanner
from core.subdomain import SubdomainEnumerator
from core.dirbuster import DirBuster
from core.tech_detect import TechnologyDetector
from core.waf_detect import WAFDetector
from scanners.vuln_scanner import VulnerabilityScanner

class ActiveRecon:
    def __init__(self, target):
        self.target = target.replace('https://', '').replace('http://', '').split('/')[0]
        self.base_url = f"http://{self.target}"
        self.https_url = f"https://{self.target}"
        self.results = {
            'target': self.target,
            'ip': None,
            'open_ports': [],
            'dns_records': {},
            'ssl_info': {},
            'technologies': [],
            'http_headers': {},
            'security_headers': {},
            'vulnerabilities': [],
            'subdomains': [],
            'directories': [],
            'waf_detected': None,
            'server_info': None
        }
    
    def run_all(self):
        print(f"\n[*] Starting ACTIVE reconnaissance on {self.target}")
        self.get_ip()
        self.dns_enumeration()
        self.port_scan()
        self.http_analysis()
        self.ssl_analysis()
        self.technology_detection()
        self.security_header_check()
        self.waf_detection()
        self.subdomain_enumeration()
        self.directory_bruteforce()
        self.vulnerability_scan()
        return self.results
    
    def get_ip(self):
        try:
            self.results['ip'] = socket.gethostbyname(self.target)
            print(f"[+] IP Address: {self.results['ip']}")
        except:
            print("[-] Failed to resolve IP")
    
    def dns_enumeration(self):
        record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'SOA', 'CNAME']
        for record in record_types:
            try:
                answers = dns.resolver.resolve(self.target, record)
                self.results['dns_records'][record] = [str(r) for r in answers]
            except:
                pass
        if self.results['dns_records']:
            print(f"[+] DNS records found: {len(self.results['dns_records'])} types")
    
    def port_scan(self):
        scanner = PortScanner(self.results['ip'])
        self.results['open_ports'] = scanner.scan()
        if self.results['open_ports']:
            print(f"[+] Open ports: {len(self.results['open_ports'])} found")
    
    def http_analysis(self):
        try:
            for url in [self.https_url, self.base_url]:
                try:
                    r = requests.get(url, timeout=5, verify=False)
                    self.results['http_headers'] = dict(r.headers)
                    self.results['server_info'] = r.headers.get('Server', 'Unknown')
                    print(f"[+] HTTP analysis complete for {url}")
                    break
                except:
                    continue
        except:
            pass
    
    def ssl_analysis(self):
        try:
            import ssl
            ctx = ssl.create_default_context()
            with ctx.wrap_socket(socket.socket(), server_hostname=self.target) as s:
                s.settimeout(5)
                s.connect((self.target, 443))
                cert = s.getpeercert()
                self.results['ssl_info'] = {
                    'issuer': dict(x[0] for x in cert.get('issuer', [])).get('commonName', 'Unknown'),
                    'expiry': cert.get('notAfter', 'Unknown'),
                    'subject': dict(x[0] for x in cert.get('subject', [])).get('commonName', 'Unknown')
                }
                print("[+] SSL certificate analyzed")
        except:
            pass
    
    def technology_detection(self):
        detector = TechnologyDetector(self.base_url, self.results.get('http_headers', {}))
        self.results['technologies'] = detector.detect()
        if self.results['technologies']:
            print(f"[+] Technologies detected: {len(self.results['technologies'])}")
    
    def security_header_check(self):
        headers = self.results.get('http_headers', {})
        required = ['Strict-Transport-Security', 'Content-Security-Policy', 'X-Frame-Options', 'X-Content-Type-Options']
        for header in required:
            self.results['security_headers'][header] = headers.get(header, 'Missing')
        if self.results['security_headers']:
            print(f"[+] Security headers checked")
    
    def waf_detection(self):
        detector = WAFDetector(self.base_url, self.results.get('http_headers', {}))
        self.results['waf_detected'] = detector.detect()
        if self.results['waf_detected']:
            print(f"[+] WAF detected: {self.results['waf_detected']}")
    
    def subdomain_enumeration(self):
        enumerator = SubdomainEnumerator(self.target)
        self.results['subdomains'] = enumerator.enumerate()
        if self.results['subdomains']:
            print(f"[+] Subdomains found: {len(self.results['subdomains'])}")
    
    def directory_bruteforce(self):
        buster = DirBuster(self.base_url)
        self.results['directories'] = buster.bruteforce()
        if self.results['directories']:
            print(f"[+] Directories found: {len(self.results['directories'])}")
    
    def vulnerability_scan(self):
        scanner = VulnerabilityScanner(self.base_url, self.results.get('open_ports', []), self.results.get('http_headers', {}))
        self.results['vulnerabilities'] = scanner.scan()
        if self.results['vulnerabilities']:
            print(f"[+] Vulnerabilities found: {len(self.results['vulnerabilities'])}")