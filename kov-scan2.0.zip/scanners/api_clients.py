# scanners/api_clients.py

import requests

UA = {"User-Agent": "Kov-SCAN-2.0"}

def hackertarget_http_headers(host):
    try:
        r = requests.get(f"https://api.hackertarget.com/httpheaders/?q={host}", timeout=10)
        if r.status_code == 200:
            return r.text
    except:
        pass
    return None

def hackertarget_whatweb(host):
    try:
        r = requests.get(f"https://api.hackertarget.com/whatweb/?q={host}", timeout=10)
        if r.status_code == 200:
            return r.text
    except:
        pass
    return None

def hackertarget_dnslookup(host):
    try:
        r = requests.get(f"https://api.hackertarget.com/dnslookup/?q={host}", timeout=10)
        if r.status_code == 200:
            return r.text
    except:
        pass
    return None

def hackertarget_hostsearch(host):
    try:
        r = requests.get(f"https://api.hackertarget.com/hostsearch/?q={host}", timeout=10)
        if r.status_code == 200:
            return r.text
    except:
        pass
    return None

def hackertarget_whois(host):
    try:
        r = requests.get(f"https://api.hackertarget.com/whois/?q={host}", timeout=10)
        if r.status_code == 200:
            return r.text
    except:
        pass
    return None

def securityheaders_dot_com(host):
    try:
        r = requests.get(f"https://securityheaders.com/?q={host}&followRedirects=on", timeout=10)
        if r.status_code == 200:
            return r.text
    except:
        pass
    return None

def ip_api_info(query):
    try:
        r = requests.get(f"http://ip-api.com/json/{query}", timeout=8)
        if r.status_code == 200:
            return r.json()
    except:
        pass
    return None

def threatminer_domain_report(host):
    try:
        r = requests.get(f"https://api.threatminer.org/v2/domain.php?q={host}&rt=5", timeout=10)
        if r.status_code == 200:
            return r.json()
    except:
        pass
    return None

def wayback_snapshot(host):
    try:
        r = requests.get(f"https://archive.org/wayback/available?url={host}", timeout=10)
        if r.status_code == 200:
            return r.json()
    except:
        pass
    return None

def urlscan_search(host):
    try:
        r = requests.get(f"https://urlscan.io/api/v1/search/?q=domain:{host}", timeout=10)
        if r.status_code == 200:
            return r.json()
    except:
        pass
    return None