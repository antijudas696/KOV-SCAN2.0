"""
KOV-SCAN 2.0 Vulnerability Scanner Module
Created by: brutozin.kov
"""

import requests

class VulnerabilityScanner:
    def __init__(self, url, open_ports, headers):
        self.url = url
        self.open_ports = open_ports
        self.headers = headers
        self.vulnerabilities = []
    
    def scan(self):
        self.check_open_ports()
        self.check_security_headers()
        self.check_server_info()
        self.check_common_paths()
        return self.vulnerabilities
    
    def check_open_ports(self):
        vuln_ports = {
            21: 'FTP - Anonymous login may be enabled',
            22: 'SSH - Weak encryption may be configured',
            3306: 'MySQL - Database exposed to internet',
            3389: 'RDP - Remote Desktop exposed',
            5900: 'VNC - VNC service exposed'
        }
        for port, service in self.open_ports:
            if port in vuln_ports:
                self.vulnerabilities.append(('MEDIUM', f"Port {port}: {vuln_ports[port]}"))
    
    def check_security_headers(self):
        missing = []
        required = ['Strict-Transport-Security', 'Content-Security-Policy', 'X-Frame-Options', 'X-Content-Type-Options']
        for header in required:
            if header not in self.headers:
                missing.append(header)
        if missing:
            self.vulnerabilities.append(('HIGH', f"Missing security headers: {', '.join(missing)}"))
    
    def check_server_info(self):
        server = self.headers.get('Server', '')
        if server:
            if any(v in server.lower() for v in ['apache/2.2', 'nginx/1.0', 'iis/6.0', 'iis/7.0']):
                self.vulnerabilities.append(('HIGH', f"Outdated server version: {server}"))
    
    def check_common_paths(self):
        sensitive = ['.env', 'config.php', 'wp-config.php', '.git/HEAD', 'backup.zip', 'database.sql']
        for path in sensitive:
            try:
                r = requests.get(f"{self.url}/{path}", timeout=3)
                if r.status_code == 200:
                    self.vulnerabilities.append(('CRITICAL', f"Sensitive file exposed: /{path}"))
            except:
                pass