#!/usr/bin/env python3
"""
KOV-SCAN 2.0 Installer for Termux
Created by: brutozin.kov
"""

import subprocess
import sys
import os

def run_command(cmd):
    try:
        print(f"[*] Running: {cmd}")
        subprocess.check_call(cmd, shell=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"[-] Failed: {e}")
        return False

def check_pip():
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "--version"], stdout=subprocess.DEVNULL)
        return True
    except:
        return False

def termux_setup():
    print("\n[*] Setting up Termux...")
    run_command("pkg update -y")
    run_command("pkg upgrade -y")
    run_command("pkg install python -y")
    run_command("pkg install rust -y")
    run_command("pkg install binutils -y")
    run_command("pkg install openssl -y")
    run_command("pkg install libffi -y")
    run_command("pkg install clang -y")
    return True

def install_requirements():
    packages = [
        "requests",
        "beautifulsoup4",
        "colorama",
        "dnspython",
        "flask"
    ]
    
    print("\n[*] Installing Python packages...")
    for package in packages:
        print(f"[*] Installing {package}...")
        if not run_command(f"{sys.executable} -m pip install {package}"):
            print(f"[-] Failed to install {package}")
            return False
    
    print("\n[*] Installing pyOpenSSL with Rust workaround...")
    run_command("pip install setuptools-rust")
    run_command("pip install cryptography --no-binary cryptography")
    run_command("pip install pyopenssl")
    
    return True

def verify_installation():
    print("\n[*] Verifying installation...")
    try:
        import requests, bs4, colorama, dns, flask
        print("[+] Core packages OK")
        try:
            import OpenSSL
            print("[+] pyOpenSSL OK")
        except:
            print("[!] pyOpenSSL not installed (optional for SSL analysis)")
        return True
    except Exception as e:
        print(f"[-] Verification failed: {e}")
        return False

def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║              KOV-SCAN 2.0 TERMUX INSTALLER                   ║
║                 Created by: brutozin.kov                     ║
╚══════════════════════════════════════════════════════════════╝
    """)
    
    print("[!] This installer is optimized for Termux on Android")
    print("[!] Make sure you have internet connection\n")
    
    termux_setup()
    
    if install_requirements():
        verify_installation()
        print("""
╔══════════════════════════════════════════════════════════════╗
║  ✅ INSTALLATION COMPLETE!                                   ║
║                                                              ║
║  Run KOV-SCAN 2.0:                                          ║
║    python app.py                                             ║
║    python app.py -t example.com                              ║
║    python app.py -g                                          ║
║                                                              ║
║  Note: GUI mode may not work in Termux. Use CLI mode.       ║
║  Stay legal. Scan only authorized targets.                  ║
╚══════════════════════════════════════════════════════════════╝
        """)
    else:
        print("""
╔══════════════════════════════════════════════════════════════╗
║  ❌ INSTALLATION FAILED                                      ║
║                                                              ║
║  Try manual install:                                         ║
║    pkg install rust binutils openssl libffi clang           ║
║    pip install requests beautifulsoup4 colorama dnspython   ║
║    pip install flask                                        ║
║    pip install cryptography --no-binary cryptography        ║
║    pip install pyopenssl                                    ║
╚══════════════════════════════════════════════════════════════╝
        """)
        sys.exit(1)

if __name__ == "__main__":
    main()
