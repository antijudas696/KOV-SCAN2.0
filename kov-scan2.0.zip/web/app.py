"""
KOV-SCAN 2.0 Web GUI
Created by: brutozin.kov
"""

from flask import Flask, render_template, request, jsonify
import threading
import json
from scanners.passive_checks import all_in_one_passive
from scanners.active_checks import ActiveRecon

app = Flask(__name__)
scan_results = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan', methods=['POST'])
def scan():
    target = request.json.get('target')
    if not target:
        return jsonify({'error': 'No target provided'}), 400
    
    def run_scan():
        passive = all_in_one_passive(target)
        active = ActiveRecon(target)
        active_results = active.run_all()
        scan_results[target] = {**passive, **active_results}
    
    thread = threading.Thread(target=run_scan)
    thread.start()
    
    return jsonify({'status': 'scanning', 'target': target})

@app.route('/results/<target>')
def results(target):
    if target in scan_results:
        return jsonify(scan_results[target])
    return jsonify({'status': 'scanning or not found'})

if __name__ == '__main__':
    app.run(debug=True)