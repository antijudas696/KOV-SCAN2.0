# KOV-SCAN 2.0 Web Package
# Created by: brutozin.kov

from .app import app