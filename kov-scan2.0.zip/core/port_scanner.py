"""
KOV-SCAN 2.0 Port Scanner Module
Created by: brutozin.kov
"""

import socket
from concurrent.futures import ThreadPoolExecutor, as_completed

class PortScanner:
    def __init__(self, ip):
        self.ip = ip
        self.ports = [21,22,23,25,53,80,81,110,111,135,139,143,443,445,993,995,1723,3306,3389,5432,5900,8080,8443,27017]
        self.services = {
            21:'FTP',22:'SSH',23:'Telnet',25:'SMTP',53:'DNS',80:'HTTP',81:'HTTP-Alt',
            110:'POP3',111:'RPC',135:'RPC',139:'NetBIOS',143:'IMAP',443:'HTTPS',
            445:'SMB',993:'IMAPS',995:'POP3S',1723:'PPTP',3306:'MySQL',3389:'RDP',
            5432:'PostgreSQL',5900:'VNC',8080:'HTTP-Proxy',8443:'HTTPS-Alt',27017:'MongoDB'
        }
    
    def scan(self):
        open_ports = []
        def scan_port(port):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((self.ip, port))
                sock.close()
                if result == 0:
                    return (port, self.services.get(port, 'Unknown'))
            except:
                pass
            return None
        
        with ThreadPoolExecutor(max_workers=50) as executor:
            futures = [executor.submit(scan_port, port) for port in self.ports]
            for future in as_completed(futures):
                result = future.result()
                if result:
                    open_ports.append(result)
        return open_ports