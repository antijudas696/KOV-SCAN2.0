"""
KOV-SCAN 2.0 Directory Brute Forcing Module
Created by: brutozin.kov
"""

import requests

class DirBuster:
    def __init__(self, base_url):
        self.base_url = base_url.rstrip('/')
        self.directories = [
            'admin', 'login', 'wp-admin', 'backup', 'config', 'api', 'test', 'dev', 'uploads', 'css', 'js',
            'images', 'img', 'assets', 'static', 'includes', 'inc', 'modules', 'plugins', 'themes', 'vendor',
            'tmp', 'temp', 'logs', 'storage', 'database', 'db', 'sql', 'dump', 'old', 'new', 'v1', 'v2',
            'private', 'secret', 'hidden', '.git', '.svn', '.env', 'phpinfo', 'info', 'dashboard', 'panel'
        ]
    
    def bruteforce(self):
        found = []
        for directory in self.directories:
            try:
                url = f"{self.base_url}/{directory}"
                r = requests.get(url, timeout=3)
                if r.status_code == 200:
                    found.append((directory, r.status_code))
                    print(f"[+] Directory found: /{directory}")
                elif r.status_code == 403:
                    found.append((directory, 403))
                    print(f"[+] Directory found (forbidden): /{directory}")
            except:
                pass
        return found