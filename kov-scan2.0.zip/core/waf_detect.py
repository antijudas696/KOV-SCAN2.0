"""
KOV-SCAN 2.0 WAF Detection Module
Created by: brutozin.kov
"""

class WAFDetector:
    def __init__(self, url, headers):
        self.url = url
        self.headers = headers
        self.waf_signatures = {
            'Cloudflare': ['cloudflare', 'cf-ray', '__cfduid'],
            'Sucuri': ['sucuri', 'x-sucuri-id'],
            'ModSecurity': ['mod_security', 'modsecurity'],
            'AWS WAF': ['x-amzn-requestid', 'aws'],
            'Akamai': ['akamai', 'x-akamai'],
            'Imperva': ['incap_ses', 'visid_incap'],
            'F5 BIG-IP': ['bigip', 'f5']
        }
    
    def detect(self):
        headers_str = str(self.headers).lower()
        for waf, signatures in self.waf_signatures.items():
            for sig in signatures:
                if sig in headers_str:
                    return waf
        return None