"""
KOV-SCAN 2.0 Subdomain Enumeration Module
Created by: brutozin.kov
"""

import requests
import json

class SubdomainEnumerator:
    def __init__(self, domain):
        self.domain = domain
        self.api_key = "at_BtouVh0iKdYPMIRdZ9Wx3ttRUtGZe"
    
    def enumerate(self):
        found = []
        
        try:
            url = f"https://subdomain-reverse.whoisxmlapi.com/api/v1"
            params = {
                "apiKey": self.api_key,
                "domainName": self.domain
            }
            
            response = requests.get(url, params=params, timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                subdomains = data.get("result", [])
                
                for item in subdomains:
                    sub = item.get("domainName", "")
                    if sub:
                        found.append(sub)
                        print(f"[+] Subdomain found: {sub}")
                
                if found:
                    print(f"[+] Total subdomains found: {len(found)}")
                else:
                    print("[!] No subdomains found via API")
            
            else:
                print(f"[-] API error: {response.status_code}")
                
        except Exception as e:
            print(f"[-] API request failed: {e}")
        
        return found