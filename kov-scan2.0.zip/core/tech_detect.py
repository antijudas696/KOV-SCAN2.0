"""
KOV-SCAN 2.0 Technology Detection Module
Created by: brutozin.kov
"""

import requests

class TechnologyDetector:
    def __init__(self, url, headers):
        self.url = url
        self.headers = headers
        self.technologies = []
    
    def detect(self):
        if 'Server' in self.headers:
            self.technologies.append(f"Server: {self.headers['Server']}")
        if 'X-Powered-By' in self.headers:
            self.technologies.append(f"Powered by: {self.headers['X-Powered-By']}")
        
        try:
            r = requests.get(self.url, timeout=5)
            html = r.text.lower()
            
            cms_signatures = [
                ('wp-content', 'WordPress'), ('joomla', 'Joomla'), ('drupal', 'Drupal'),
                ('laravel', 'Laravel'), ('symfony', 'Symfony'), ('codeigniter', 'CodeIgniter'),
                ('yii', 'Yii'), ('cakephp', 'CakePHP'), ('ruby on rails', 'Ruby on Rails'),
                ('django', 'Django'), ('flask', 'Flask'), ('express', 'Express.js')
            ]
            
            for sig, name in cms_signatures:
                if sig in html:
                    self.technologies.append(name)
        except:
            pass
        
        return self.technologies