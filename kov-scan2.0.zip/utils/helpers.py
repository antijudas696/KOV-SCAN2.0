"""
KOV-SCAN 2.0 Helper Functions
Created by: brutozin.kov
"""

import sys, subprocess, pkgutil, importlib
import datetime, os

UA = {"User-Agent": "KOV-SCAN-2.0"}

def ensure_requirements():
    reqs = ["requests","bs4","colorama","dnspython","flask","pyOpenSSL"]
    missing = []
    for r in reqs:
        if not pkgutil.find_loader(r):
            missing.append(r)
    if missing:
        print("Missing Python packages detected. Installing:", ", ".join(missing))
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)
        except Exception as e:
            print("Auto-install failed. Please run: pip install -r requirements.txt")
            return False
    return True

def save_scan_to_file(scan_obj, filename):
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write("KOV-SCAN 2.0 - Scan Report\n")
            f.write(f"Created by: brutozin.kov\n")
            f.write(f"Generated: {datetime.datetime.utcnow().isoformat()}Z\n\n")
            f.write(f"Target: {scan_obj.get('target')}\n")
            f.write(f"IP: {scan_obj.get('ip')}\n")
            f.write(f"Summary: {scan_obj.get('summary')}\n\n")
            f.write("--- HTTP HEADERS ---\n")
            for hk,hv in (scan_obj.get("headers") or {}).items():
                f.write(f"{hk}: {hv}\n")
            f.write("\n--- HTML NOTES ---\n")
            for n in scan_obj.get("html_notes", []):
                f.write(f"{n}\n")
            f.write("\n--- COMMON PATHS ---\n")
            for p,c in scan_obj.get("common_paths", []):
                f.write(f"/{p} -> {c}\n")
        return True
    except Exception as e:
        return False

def save_scan_prompt(scan_obj):
    ans = input("Save scan result? (y/n): ").strip().lower()
    if ans != "y":
        return
    fname = input("Filename (e.g. report.txt): ").strip()
    if not fname:
        fname = f"kov_{scan_obj.get('target','scan')}.txt"
    ok = save_scan_to_file(scan_obj, fname)
    if ok:
        print(f"Saved to {fname}")
    else:
        print("Failed to save file (permission?).")